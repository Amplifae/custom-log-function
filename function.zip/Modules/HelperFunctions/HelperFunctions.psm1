Function Set-LogAnalyticsData {
    param (
        [Parameter(Mandatory = $true)]
        [string]$workspaceId,

        [Parameter(Mandatory = $true)]
        [securestring]$workspaceKey,

        [Parameter(Mandatory = $true)]
        [array]$body,

        [Parameter(Mandatory = $true)]
        [string]$logType,

        [Parameter(Mandatory = $true)]
        [string]$timestamp
    )

    $properties = @{
        "WorkspaceId"   = $workspaceId
        "WorkspaceKey"  = $workspaceKey
        "contentLength" = $body.Length
        "timestamp"     = $timestamp
    }

    $payload = @{
        "Headers"     = @{
            "Authorization" = Build-Signature @properties
            "Log-Type"      = $logType
            "x-ms-date"     = $timestamp
        }
        "method"      = "POST"
        "contentType" = "application/json"
        "uri"         = "https://{0}.ods.opinsights.azure.com/api/logs?api-version=2016-04-01" -f $workspaceId
        "body"        = $body
    }

    $response = Invoke-WebRequest @payload -UseBasicParsing

    if (-not($response.StatusCode -eq 200)) {
        Write-Warning "Unable to send data to Data Log Collector table"
        break
    }
    else {
        Write-Output "Uploaded to Data Log Collector table [$($logType + '_CL')] at [$timestamp]"
    }
}

Function Build-Signature {
    param (
        [Parameter(Mandatory = $true)]
        [String]$workspaceId,

        [Parameter(Mandatory = $true)]
        [SecureString]$workspaceKey,

        [Parameter(Mandatory = $true)]
        [Int32]$contentLength,

        [Parameter(Mandatory = $true)]
        [string]$timestamp
    )

    $xHeaders = "x-ms-date:" + $timestamp
    $stringToHash = "POST" + "`n" + $contentLength + "`n" + "application/json" + "`n" + $xHeaders + "`n" + "/api/logs"
    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String((ConvertFrom-SecureString -SecureString $workspaceKey -AsPlainText))
    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $workspaceId, $encodedHash

    return $authorization
}

Function Set-TimeStamp {
    param (
        [Parameter(Mandatory = $false)]
        [string]$lastRun,

        [Parameter(Mandatory = $true)]
        [string]$AzureWebJobsStorage,

        [Parameter(Mandatory = $true)]
        [string]$storageAccountContainer
    )

    if ([string]::IsNullOrEmpty($lastRun)) {
        $lastRun = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
    }

    $lastRunAudit = @{
        'lastRun' = $lastRun
    }

    $lastRunAudit | ConvertTo-Json | Out-File "$env:temp\timestamp.json"

    try {
        Write-Verbose "Selecting Storage Context"
        $storageAccountContext = New-AzStorageContext -ConnectionString $AzureWebJobsStorage
    }
    catch {
        return 'Unable to connect to Storage Context'
    }

    Write-Verbose 'Saving new timestamp'
    try {
        $null = Set-AzStorageBlobContent `
            -Blob "timestamp.json" `
            -Container $storageAccountContainer `
            -Context $storageAccountContext `
            -File "$env:temp\timestamp.json" `
            -Force
    }
    catch {
        return 'Unable to create new timestamp'
    }
    return $lastRun
}

Function Get-TimeStamp {
    param (
        [Parameter(Mandatory = $true)]
        [string]$AzureWebJobsStorage,

        [Parameter(Mandatory = $true)]
        [string]$storageAccountContainer
    )

    $storageAccountContext = New-AzStorageContext -ConnectionString $AzureWebJobsStorage

    try {
        Write-Verbose "Get Blob Context"
        $blobContext = Get-AzStorageBlob `
            -Blob "timestamp.json" `
            -Container $storageAccountContainer `
            -Context $storageAccountContext
    }
    catch {
        Write-Output "Unable to access [timestamp.json]"
    }

    if (![string]::IsNullOrEmpty($blobContext)) {
        Write-Verbose "Get Blob File"
        $null = Get-AzStorageBlobContent `
            -Blob "timestamp.json" `
            -Container $storageAccountContainer `
            -Context $storageAccountContext `
            -Destination "$env:temp\timestamp.json" `
            -Force

        Write-Verbose "Get File Content"
        $lastRunAuditContext = Get-Content "$env:temp\timestamp.json" | ConvertFrom-Json
        if ($null -ne $lastRunAuditContext) {
            $timestamp = ($lastRunAuditContext.lastRun).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        }
        else {
            $timestamp = Set-TimeStamp
        }
        return $timestamp
    }
}

Function Get-Workspace {
    param (
        [Parameter(Mandatory = $false)]
        [string]$workspaceName
    )

    if (-not([string]::IsNullOrEmpty($workspaceName))) {
        try {
            $workspaceObject = @{
                workspaceId  = ''
                workspaceKey = ''
            }
            Write-Verbose "Connecting to workspace"

            $workspace = Get-AzResource `
                -Name "$WorkspaceName" `
                -ResourceType 'Microsoft.OperationalInsights/workspaces'

            $ResourceGroupName = $workspace.ResourceGroupName
            $workspaceName = $workspace.Name

            $workspaceObject.workspaceId = (Get-AzOperationalInsightsWorkspace -ResourceGroupName $resourceGroupName -Name $workspaceName).CustomerId.Guid

            Write-Host "Workspace Name: $($workspaceName)"
            Write-Host "Workspace Id: $($workspaceId)"

            if ($null -ne $workspace) {
                try {
                    Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"

                    $workspaceObject.workspaceKey = `
                        (Get-AzOperationalInsightsWorkspaceSharedKeys `
                            -ResourceGroupName $ResourceGroupName `
                            -Name $WorkspaceName).PrimarySharedKey `
                            | ConvertTo-SecureString -AsPlainText -Force
                }
                catch {
                    Write-Warning -Message "Log Analytics workspace key for [$($WorkspaceName)] not found."
                    break
                }
            }
            return $workspaceObject
        }
        catch {
            Write-Warning -Message "Log Analytics workspace [$($WorkspaceName)] not found in the current context"
            break
        }
    }
}

function Send-CustomLogs {
    param (
        [Parameter(Mandatory = $true)]
        [String]$workspaceId,

        [Parameter(Mandatory = $true)]
        [SecureString]$workspaceKey,

        [Parameter(Mandatory = $true)]
        [string]$tableName,

        [Parameter(Mandatory = $true)]
        [array]$customData
    )

    $postObject = @{
        "workspaceId"  = $workspaceId
        "WorkspaceKey" = $workspaceKey
        "logType"      = $tableName
        "body"         = ''
        "timestamp"    = ''
    }

    $tempdata = @()
    $tempDataSize = 0

    if ((($customData | ConvertTo-Json -depth 20).Length) -gt 25MB) {
        Write-Host "Upload is over 25MB, needs to be split"
        foreach ($record in $customData) {
            $tempdata += $record
            $tempDataSize += ($record | ConvertTo-Json -depth 20).Length
            if ($tempDataSize -gt 25MB) {
                $postObject.body = ([System.Text.Encoding]::UTF8.GetBytes(($tempdata | ConvertTo-Json)))
                $postObject.timestamp = [DateTime]::UtcNow.ToString("r")

                write-Host "Sending block data = $TempDataSize"
                Set-LogAnalyticsData @postObject

                $tempdata = $null
                $tempdata = @()
                $tempDataSize = 0
            }
        }
        $postObject.body = ([System.Text.Encoding]::UTF8.GetBytes(($tempdata | ConvertTo-Json -depth 20)))
        $postObject.timestamp = [DateTime]::UtcNow.ToString("r")

        Write-Host "Sending left over data = $Tempdatasize"
        Set-LogAnalyticsData @postObject

        $tempdata = $null
        $tempdata = @()
        $tempDataSize = 0
    }
    else {
        $postObject.body = ([System.Text.Encoding]::UTF8.GetBytes(($customData | ConvertTo-Json -depth 20)))
        $postObject.timestamp = [DateTime]::UtcNow.ToString("r")
    }
    Write-Host "Sending data"
    Set-LogAnalyticsData @postObject
}